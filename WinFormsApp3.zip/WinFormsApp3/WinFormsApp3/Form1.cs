namespace WinFormsApp3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            var currencyRequestManager = new CurrencyRequestManager();
            var usdExchangeRate = currencyRequestManager.GetUsdExchangeRate();

            label2.Text = usdExchangeRate;

            InitializeComponent();

            var eurExchangeRate = currencyRequestManager.GetEurExchangeRate();

            label4.Text = eurExchangeRate;

            InitializeComponent();

            var gbpExchangeRate = currencyRequestManager.GetGbpExchangeRate();

            label6.Text = gbpExchangeRate;

            InitializeComponent();

            var gold = currencyRequestManager.Gold();

            label8.Text = gold;
        }
    }
}