﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormsApp3
{
    public class CurrencyRequestManager
    {
        public string GetUsdExchangeRate()
        {
            using (var httpClient = new HttpClient())
            {
                var request = new HttpRequestMessage(HttpMethod.Get, $"http://api.nbp.pl/api/exchangerates/rates/a/usd?format=json");
                var responseMessage = httpClient.SendAsync(request).Result;
                var responseContent = responseMessage.Content.ReadAsStringAsync().Result;

                var currencyInfo = JsonConvert.DeserializeObject<CurrencyInfo>(responseContent);
                return currencyInfo.Rates.First().Mid;
            }
        }

        public string GetEurExchangeRate()
        {
            using (var httpClient = new HttpClient())
            {
                var request = new HttpRequestMessage(HttpMethod.Get, $"http://api.nbp.pl/api/exchangerates/rates/a/eur?format=json");
                var responseMessage = httpClient.SendAsync(request).Result;
                var responseContent = responseMessage.Content.ReadAsStringAsync().Result;

                var currencyInfo = JsonConvert.DeserializeObject<CurrencyInfo>(responseContent);
                return currencyInfo.Rates.First().Mid;
            }
        }

        public string GetGbpExchangeRate()
        {
            using (var httpClient = new HttpClient())
            {
                var request = new HttpRequestMessage(HttpMethod.Get, $"http://api.nbp.pl/api/exchangerates/rates/a/gbp?format=json");
                var responseMessage = httpClient.SendAsync(request).Result;
                var responseContent = responseMessage.Content.ReadAsStringAsync().Result;

                var currencyInfo = JsonConvert.DeserializeObject<CurrencyInfo>(responseContent);
                return currencyInfo.Rates.First().Mid;
            }
        }

        public string Gold()
        {
            using (var httpClient = new HttpClient())
            {

                var request = new HttpRequestMessage(HttpMethod.Get, $"http://api.nbp.pl/api/cenyzlota?format=json");
                var responseMessage = httpClient.SendAsync(request).Result;
                var responseContent = responseMessage.Content.ReadAsStringAsync().Result;

                

                var gold = JsonConvert.DeserializeObject<GoldPrice[]>(responseContent);
                return gold[0].Cena;
            }
        }
    }
    
}
