﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormsApp3
{
    class CurrencyRateInfo
    {
        public string No { get; set; }
        public string EffectiveDate { get; set; }
        public string Mid { get; set; }
    }
}
