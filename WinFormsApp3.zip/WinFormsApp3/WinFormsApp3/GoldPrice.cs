﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormsApp3
{
    class GoldPrice
    {
        public string Data { get; set; }
        public string Cena { get; set; }
    }
}
 